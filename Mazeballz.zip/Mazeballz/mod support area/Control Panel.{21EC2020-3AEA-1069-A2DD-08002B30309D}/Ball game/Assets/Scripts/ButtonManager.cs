﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;


public class ButtonManager : MonoBehaviour
{
    public void NewGameBtn(string newGameLevel)
    {
        SceneManager.LoadScene(newGameLevel);
    }
    public void ExitGameBtn()
    {
        Application.Quit();
    }
    public void LevelSelectButton(string newLevelselect)
    {
        SceneManager.LoadScene(newLevelselect);
    }
    public void Level1Btn(string newLevel1)
    {
        SceneManager.LoadScene(newLevel1);
    }
    public void Level2Btn(string newLevel2)
    {
        SceneManager.LoadScene(newLevel2);
    }
    public void BackBtn(string newBack)
    {
        SceneManager.LoadScene(newBack);
    }
    public void CreditsBtn(string newCredits)
    {
        SceneManager.LoadScene(newCredits);
    }
    public void LevelSelectButton2(string newLevelselect2)
    {
        SceneManager.LoadScene(newLevelselect2);
    }
    public void Level3Btn(string newLevel3)
    {
        SceneManager.LoadScene(newLevel3);
    }
}
